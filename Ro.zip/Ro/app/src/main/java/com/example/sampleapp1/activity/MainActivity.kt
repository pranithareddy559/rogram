package com.example.sampleapp1.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.example.sampleapp1.R
import com.example.sampleapp1.adapter.ItemAdapter
import com.example.sampleapp1.model.RogramList
import com.example.sampleapp1.model.RogramListItem
import com.example.sampleapp1.network.NetworkRequestQueue
import com.google.gson.Gson
import org.json.JSONArray

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val url = "https://jsonplaceholder.typicode.com/album/1/photos"
        val myDataset = emptyList<RogramListItem>()
        val recyclerView = findViewById<RecyclerView>(R.id.recycler_view)
        val adapter = ItemAdapter(this, myDataset, { rogramListItem -> adapterOnClick(rogramListItem) })
        recyclerView.adapter = adapter
        recyclerView.setHasFixedSize(true)
        val jsonArrayRequest = JsonArrayRequest(
            Request.Method.GET, url,
            null,
            Response.Listener<JSONArray> { response ->
                var respString = response.toString()
                var list = Gson().fromJson(respString, RogramList::class.java)
                adapter.update(list)
            },
            Response.ErrorListener {  })

        NetworkRequestQueue().getInstance(this.applicationContext)?.addToRequestQueue(jsonArrayRequest)
    }

    override fun onStop() {
        super.onStop()
    }

    private fun adapterOnClick(rogramListItem: RogramListItem) {
        val intent = Intent(this, RogramIDetailActivity()::class.java)
        intent.putExtra("url", rogramListItem.url)
        intent.putExtra("title", rogramListItem.title)
        startActivity(intent)
    }
}