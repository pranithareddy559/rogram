package com.example.sampleapp1.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.sampleapp1.R

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
class RogramIDetailActivity : AppCompatActivity() {

    private var imageUrl = ""
    private var title = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rogram_idetail)
        val imageView: ImageView = findViewById(R.id.detail_image)
        val titleView: TextView = findViewById(R.id.detail_description)
        val bundle: Bundle? = intent.extras
        if (bundle != null) {
            imageUrl = bundle.getString("url", "")
            title = bundle.getString("title", "")
        }
        Glide.with(this.applicationContext)
            .load(imageUrl+".png")
            .placeholder(R.drawable.ic_launcher_foreground)
            .error(R.drawable.ic_launcher_background)
            .into(imageView)
        titleView.text = title
        imageView.setOnClickListener {
            finish()
        }
    }
}