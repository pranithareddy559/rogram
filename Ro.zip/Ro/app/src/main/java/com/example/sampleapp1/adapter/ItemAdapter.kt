package com.example.sampleapp1.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.sampleapp1.R
import com.example.sampleapp1.model.RogramListItem

class ItemAdapter(
    private val context: Context,
    private var dataset: List<RogramListItem>,
    private val onClick: (RogramListItem) -> Unit
) : RecyclerView.Adapter<ItemAdapter.ItemViewHolder>(){

    class ItemViewHolder(private val view: View, val onClick: (RogramListItem) -> Unit) : RecyclerView.ViewHolder(view) {
        private var currentRogramListItem: RogramListItem? = null
        val textView: TextView = view.findViewById(R.id.item_title)
        val imageView: ImageView = view.findViewById(R.id.item_image)

        init {
            view.setOnClickListener {
                currentRogramListItem?.let {
                    onClick(it)
                }
            }
        }
        public fun bind(rogramListItem: RogramListItem) {
            currentRogramListItem = rogramListItem
            Glide.with(this.view.context)
                .load(rogramListItem.thumbnailUrl+".png")
                .placeholder(R.drawable.ic_launcher_foreground)
                .error(R.drawable.ic_launcher_background)
                .into(imageView)
            textView.text = rogramListItem.title
        }
    }

    fun update(modelList:List<RogramListItem>){
        dataset = modelList
        this.notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item, parent, false)
        return ItemViewHolder(adapterLayout, onClick)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.bind(dataset[position])
    }

    override fun getItemCount() = dataset.size
}