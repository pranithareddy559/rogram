package com.example.sampleapp1.network

import android.content.Context

import com.android.volley.RequestQueue

import com.android.volley.Request
import com.android.volley.toolbox.*

class NetworkRequestQueue {
    private var context: Context? = null
    private var requestQueue: RequestQueue? = null
    private var networkRequestQueue: NetworkRequestQueue? = null
    constructor(context: Context) {
        this.context = context
        requestQueue = Volley.newRequestQueue(context)
        requestQueue?.start()
    }

    constructor(){

    }

    public fun getInstance(context: Context): NetworkRequestQueue? {
        if (networkRequestQueue == null) {
            networkRequestQueue = NetworkRequestQueue(context)
        }
        return networkRequestQueue
    }

    fun getRequestQueue(): RequestQueue? {
        return requestQueue
    }

    fun <T> addToRequestQueue(req: Request<T>) {
        requestQueue?.add(req)
    }
}
