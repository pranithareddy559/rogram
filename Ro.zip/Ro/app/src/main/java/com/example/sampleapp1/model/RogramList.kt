package com.example.sampleapp1.model

class RogramList : ArrayList<RogramListItem>()